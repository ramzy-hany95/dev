
export const API_URL = 'https://reqres.in/api'
