<template>
    <div class="homePage-component">
        <div class="background">
            <img src="../static/images/Web-bg.png" alt="background">
        </div>
        <div class="content">
            <h1>Welcome to our CRUD System</h1>
            <nuxt-link class="btn" to="/login">Login <i class="fas fa-sign-in-alt"></i></nuxt-link>
        </div>
    </div>
</template>