<template>
  <div class="container">
    <div>
      <homePageComponent />
    </div>
  </div>
</template>

<script>
import homePageComponent from '../components/HomePage';
export default {
      components: {
      homePageComponent,
    }
}
</script>
