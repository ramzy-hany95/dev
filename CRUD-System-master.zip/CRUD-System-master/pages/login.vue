<template>
  <div class="container">
    <div>
      <loginComponent />
    </div>
  </div>
</template>

<script>
import loginComponent from '../components/Login';
export default {
      components: {
      loginComponent,
    }
}
</script>